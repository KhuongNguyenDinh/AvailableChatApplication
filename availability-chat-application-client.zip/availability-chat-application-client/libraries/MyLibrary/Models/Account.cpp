#include "Account.h"

namespace MyLibrary::Models
{
    Account::Account(string username, string password, string role, int roomid)
    {
        Username = username;
        Password = password;
        RoomID = roomid;
        Role = role;
    }
} // namespace MyLibrary::Models
