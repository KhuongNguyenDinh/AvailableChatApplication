#pragma once

#include <string>

using namespace std;

namespace MyLibrary::Models
{
    class Account
    {
    public:
        Account(string username, string password, string role, int roomid);
        string Username;
        string Password;
        int RoomID;
        string Role;
    };

} // namespace MyLibrary::Models
