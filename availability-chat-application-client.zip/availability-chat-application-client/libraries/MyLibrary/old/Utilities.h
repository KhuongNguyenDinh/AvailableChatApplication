#ifndef _UTILITIES_H
#define _UTILITIES_H

#include <iostream>
#include <string>

#include <cpprest/json.h>
using namespace utility;

using namespace std;
using namespace web;

size_t writeCallback(char *contents, size_t size, size_t nmemb, void *userp);
json::value parseStringToJson(string const &input);

#define PORT_NO 8080
#define MSG_MAX_LEN 256
#define UNAM_MAX_LEN 32
#define SEND_CNT_MAX_LEN 300

enum ERROR_CODE
{
    AUTH_SUCCESS = 0x0000,
    UNAME_NOT_FOUND = 0x0001,
    PASSWD_INVALID = 0x0002,
    UNKNOW = 0xFFFF,
};

enum DATABASE_RETURN_CODE
{
    SUCCESS = 0x0000,
    INVALID_ROOMID = 0x0001,
    UNFOUND_ROOM_USERS = 0x0002,

    INVALID_GROUPID = 0x0010,
    UNFOUND_GROUP_SERS = 0x0011,

};
enum RECEIVED_MESSAGE_CODE
{
    UNKNOWN_SOCKET = 0x0001,
    SETUP_TIMEOUT_FAILED = 0x0002,
    INVALID_SEND_FORMAT = 0x0003,
    INVALID_REQROOM_FORMAT = 0x0004,
    INVALID_RECEIVE_FORMAT = 0x0005,

};
#endif
