#include "Utilities.h"

size_t writeCallback(char *contents, size_t size, size_t nmemb, void *userp)
{
    ((string *)userp)->append((char *)contents, size * nmemb);
    return size * nmemb;
}

json::value parseStringToJson(string const &input)
{
    if (input == "")
        return json::value::object();
    utility::stringstream_t s;
    s << input;
    web::json::value ret = json::value::parse(s);
    return ret;
}
