#include <gtest/gtest.h>
#include "Database.h"
#include "Account.h"
#include "Groupchat.h"
#include "Utilities.h"
#include "MyLibrary.h"
using namespace MyLibrary;
// using::testing::AtLeast;
// using::testing::Return;
// using::testing::_;

Database *db = Database::getInstance();

TEST(createChatRoom, CanCreateChatRoom)
{
  vector<string> users;
  users.push_back("bao");
  users.push_back("hoang");
  EXPECT_EQ(90, db->createChatRoom(users));
}

TEST(createAccount, FailToCreateAccountIfUsernameIsDuplicate)
{
  Account *h = new Account("hoang", "123456789", "1");
  EXPECT_FALSE(db->createAccount(h));
  delete h;
}

TEST(deleteAccount, DeleteNonExistAccount)
{
  EXPECT_TRUE(db->deleteAccount("khang"));
}

TEST(updateRole, UpdateInvalidRole)
{
  EXPECT_FALSE(db->updateRole("nguyen", "2"));
}

TEST(updateRole, UpdateRole)
{
  EXPECT_TRUE(db->updateRole("nguyen", "1"));
}

TEST(updateRole, ValidToUpdateRoleFromUserToAdmin)
{
  EXPECT_TRUE(db->updateRole("nguyen", "0"));
}

TEST(updateRole, ValidToUpdateRoleFromAdminToUser)
{
  EXPECT_TRUE(db->updateRole("nguyen", "1"));
}

TEST(updateRole, UpdateRoleForNonExistUser)
{
  EXPECT_TRUE(db->updateRole("khang", "1"));
}

TEST(updatePassword, UpdatePassword)
{
  EXPECT_TRUE(db->updatePassword("nguyen", "123456789"));
}

TEST(updatePassword, UpdatePasswordForNonExistUser)
{
  EXPECT_TRUE(db->updatePassword("khang", "123456789"));
}

TEST(getRoomUser, GetRoomUser)
{
  vector<string> users = db->getRoomUser(90);
  EXPECT_EQ("bao", users[0]);
  EXPECT_EQ("hoang", users[1]);
}

TEST(getRoomUser, GetNonExistRoomUser)
{
  EXPECT_TRUE(db->getRoomUser(50).empty());
}

TEST(readAccount, ReadAccount)
{
  Account *khuong = db->readAccount("khuong");
  bool readaccount;
  if ("khuong" == khuong->Username && "123456789" == khuong->Password && "1" == khuong->Role)
    readaccount = 1;
  else
    readaccount = 0;
  EXPECT_TRUE(readaccount);
}

TEST(readAccount, ReadNonExistAccount)
{
  EXPECT_EQ(NULL, db->readAccount("khang"));
}
/*
 TEST(DatabaseTest, AddMessage) {
   EXPECT_TRUE(db->addMessage("hello", 80));
 }

 TEST(DatabaseTest, AddMessageToNonExistTest) {
   EXPECT_TRUE(db->addMessage("hello", 70));
 }
*/
TEST(DatabaseTest, ReadRecentMessage)
{
  EXPECT_EQ(-1, db->readRecentMessage(80));
}

TEST(DatabaseTest, ReadMessage)
{
  EXPECT_EQ("./chat_history/80.txt", db->readMessage(80));
}

TEST(DatabaseTest, ReadMessageFromNonExistRoom)
{
  EXPECT_TRUE(db->readMessage(70).empty());
}

TEST(DatabaseTest, FailToInsertAuthenRecord)
{
  EXPECT_EQ(-2, db->insertAuthenRecord("nguyen", "2"));
}

TEST(DatabaseTest, AddUserToGroupChat)
{
  vector<string> users;
  users.push_back("hoang");
  users.push_back("hai");
  EXPECT_TRUE(db->addUserToGroupChat(users, 1));
}

TEST(DatabaseTest, DeleteUserFromGroupChat)
{
  EXPECT_TRUE(db->deleteUserFromGroupChat("khang", 1));
}

TEST(DatabaseTest, CreatePrivateGroupChatWithNullPassword)
{
  EXPECT_FALSE(db->createGroupChat("test", true, "test", ""));
}

TEST(getGroupUser, GetAllUsersInGroup)
{
  vector<string> users;
  users.push_back("hai");
  users.push_back("hoang");
  users.push_back("khuong");
  users.push_back("nguyen");
  users.push_back("SevenEleven");
  EXPECT_EQ(users, db->getGroupUser(10));
}

TEST(getGroupUser, GetAllUsersInGroupHas1Person)
{
  vector<string> users;
  users.push_back("Dat");
  EXPECT_EQ(users, db->getGroupUser(6));
}

/*
TEST(createGroupChat, CanCreateGroupChat) {
    EXPECT_TRUE(db->createGroupChat("testing room",0,"test_user","1234"));
}

TEST(createGroupChat, CanCreateGroupChatWithSameName) {
	EXPECT_TRUE(db->createGroupChat("testing room",0,"test_user","1234"));
}*/

TEST(deletGroupChat, DeleteNonExistGroupChatID)
{
  EXPECT_TRUE(db->deleteGroupChat(17));
}
/*
TEST(deletGroupChat, DeleteExistGroupChatID) {
	EXPECT_TRUE(db->deleteGroupChat(1));
}*/

TEST(getUserGroupList, GetUserFromOneGroupOnly)
{
  vector<int> k;
  k.push_back(8);
  EXPECT_EQ(k, db->getUserGroupList("Sayonara"));
}

TEST(getUserGroupList, GetUserFromManyGroups)
{
  vector<int> k;
  k.push_back(1);
  k.push_back(9);
  k.push_back(10);
  EXPECT_EQ(k, db->getUserGroupList("hai"));
}

TEST(DatabaseTest, GetUserFromManyGroupsAnd1GroupHasOnly1Person)
{
  vector<int> k;
  k.push_back(2);
  k.push_back(7);
  k.push_back(11);
  k.push_back(12);
  EXPECT_EQ(k, db->getUserGroupList("bao"));
}

TEST(updateGroupChatPassword, UpdatePasswordOfARoom)
{
  EXPECT_TRUE(db->updateGroupChatPassword("2345", 7));
}

TEST(updateGroupChatPassword, UpdatePasswordOfARoomWithTheSamePreviousPassword)
{
  EXPECT_TRUE(db->updateGroupChatPassword("1234", 7));
}

TEST(updateGroupChatPassword, UpdatePasswordOfARoomWithTheSamePassword)
{
  EXPECT_TRUE(db->updateGroupChatPassword("1234", 7));
}

TEST(updateGroupChatName, UpdateGroupChatName)
{
  EXPECT_TRUE(db->updateGroupChatName("Epic Of Remnant", 7));
}
TEST(updateGroupChatName, UpdateGroupChatNameWithTheSamePreviousName)
{
  EXPECT_TRUE(db->updateGroupChatName("Falling Temple SOLOMON", 7));
}
TEST(updateGroupChatName, UpdateGroupChatNameWithTheSameName)
{
  EXPECT_TRUE(db->updateGroupChatName("Falling Temple SOLOMON", 7));
}

TEST(readGroupchat, AbleReadPublicGroupChat)
{
  Groupchat *a, *b;
  a = new Groupchat("Gate of Chaldea", 0, "khuong", "");
  b = db->readGroupchat(5);
  EXPECT_EQ(a->Name, b->Name);
}
TEST(readGroupchat, AbleToReadPrivateGroupChat)
{
  Groupchat *a, *b;
  a = new Groupchat("Falling Temple SOLOMON", 1, "Dat", "1234");
  b = db->readGroupchat(7);
  bool khuong;
  if (a->Name == b->Name && a->Access == b->Access && a->Owner == b->Owner && a->Password == b->Password)
    khuong = 1;
  else
    khuong = 0;
  EXPECT_EQ(1, khuong);
}
int main(int argc, char **argv)
{
  testing::InitGoogleTest(&argc, argv);

  db->initialize("192.168.122.202", "admin", "Admin@25", "USER_TEST");

  return RUN_ALL_TESTS();
}