#include <gtest/gtest.h>
#include "ChatServer.h"
#include "MyLibrary.h"
#include "Utilities.h"
#include "UserInterface.h"
#include "Database.h"
#include "RestServerController.h"
#include "RequestsAndResponses.h"
#include "GroupchatService.h"
#include "helper.h"
ChatServer *sv = ChatServer::getInstance();
using namespace std;
using namespace MyLibrary;
using namespace Server::RestServer;
using namespace MyLibrary::Models::Requests;
using namespace MyLibrary::Models::Responses;
using namespace Server::RestServer::Services;
RestServerController *RestServer = NULL;

Database *MySqlServer = NULL;
ChatServer *ChatServerInstance = NULL;

TEST(InviteGroup, ValidCase)
{
    vector<string> clients;
    clients.push_back("hai");
    InviteGroupRequest req(1, clients);
    InviteGroupResponse res = GroupchatService::InviteGroup(req);
    EXPECT_EQ(RESULT_CODE::RESULT_SUCCESS, res.Result);
    EXPECT_EQ("Success", res.Status);
}

TEST(JoinGroup, InvalidGroup)
{
    JoinGroupRequest req(0, "1234", "hai");
    JoinGroupResponse res = GroupchatService::JoinGroup(req);
    EXPECT_EQ(RESULT_CODE::GROUP_INEXIST, res.Result);
    EXPECT_EQ("Group inexist", res.Status);
}

TEST(JoinPublicGroup, ValidCase)
{
    JoinGroupResponse res;
    JoinGroupRequest req(1, "1234", "hai");
    res = GroupchatService::JoinGroup(req);
    EXPECT_EQ(res.Result, 0);
    EXPECT_EQ("Success", res.Status);
}

TEST(JoinPrivateGroup, ValidCase)
{
    JoinGroupResponse res;
    JoinGroupRequest req(11, "1234", "SevenEleven");
    res = GroupchatService::JoinGroup(req);
    EXPECT_EQ(res.Result, 0);
}

TEST(JoinGroup, InvalidPassword)
{
    JoinGroupRequest req(11, "1235", "hai");
    JoinGroupResponse res = GroupchatService::JoinGroup(req);
    EXPECT_EQ(RESULT_CODE::RESULT_UNKNOWN, res.Result);
    EXPECT_EQ("Unsuccess", res.Status);
}

TEST(LeaveGroup, ValidCase)
{
    LeaveGroupRequest req(1, "khai");
    LeaveGroupResponse res = GroupchatService::LeaveGroup(req);
    EXPECT_EQ(RESULT_CODE::RESULT_SUCCESS, res.Result);
    EXPECT_EQ("Success", res.Status);
}

TEST(CreateGroup, InvalidCase)
{
    CreateGroupRequest req("test", 1, "khuong", "");
    CreateGroupResponse res = GroupchatService::CreateGroup(req);
    EXPECT_EQ(RESULT_CODE::GROUP_PASSWORD_NULL, res.Result);
    EXPECT_EQ("Password is NULL", res.Status);
}

TEST(DeleteGroup, InvalidGroup)
{
    DeleteGroupRequest req(0, "khuong", "1234");
    DeleteGroupResponse res = GroupchatService::DeleteGroup(req);
    EXPECT_EQ(RESULT_CODE::GROUP_INEXIST, res.Result);
    EXPECT_EQ("Group inexist", res.Status);
}

TEST(DeleteGroup, InvalidUsername)
{
    DeleteGroupRequest req(1, "khai", "1234");
    DeleteGroupResponse res = GroupchatService::DeleteGroup(req);
    EXPECT_EQ(RESULT_CODE::GROUP_ACCOUNT_INVALID, res.Result);
    EXPECT_EQ("Read Account Invalid", res.Status);
}

TEST(DeleteGroup, NeitherOwnerNorAdmin)
{
    DeleteGroupRequest req(1, "hai", "1234");
    DeleteGroupResponse res = GroupchatService::DeleteGroup(req);
    EXPECT_EQ(RESULT_CODE::GROUP_OWNER_OR_PASSWORD_INVALID, res.Result);
    EXPECT_EQ("Owner or Password Invalid", res.Status);
}

TEST(DeleteGroup, InvalidPassword)
{
    DeleteGroupRequest req(1, "khuong", "1235");
    DeleteGroupResponse res = GroupchatService::DeleteGroup(req);
    EXPECT_EQ(RESULT_CODE::GROUP_OWNER_OR_PASSWORD_INVALID, res.Result);
    EXPECT_EQ("Owner or Password Invalid", res.Status);
}

TEST(ModifyGroup, InvalidGroup)
{
    ModifyGroupRequest req(0, "bao", "hoi yeu quy", "1234", "4321");
    ModifyGroupResponse res = GroupchatService::ModifyGroup(req);
    EXPECT_EQ(RESULT_CODE::GROUP_INEXIST, res.Result);
    EXPECT_EQ("Group inexist", res.Status);
}

TEST(ModifyGroup, InvalidUsername)
{
    ModifyGroupRequest req(1, "khoi", "hoi yeu quy", "1234", "4321");
    ModifyGroupResponse res = GroupchatService::ModifyGroup(req);
    EXPECT_EQ(RESULT_CODE::GROUP_ACCOUNT_INVALID, res.Result);
    EXPECT_EQ("Read Account Invalid", res.Status);
}

TEST(ModifyGroup, AdminCase) {
    ModifyGroupRequest req(11, "admin", "Axis party", "1234", "1234");
    ModifyGroupResponse res = GroupchatService::ModifyGroup(req);
    EXPECT_EQ(RESULT_CODE::RESULT_SUCCESS, res.Result);
    EXPECT_EQ("Success", res.Status);
}

TEST(ModifyPrivateGroup, ValidCase) {
    ModifyGroupRequest req(11, "khuong", "Axis party", "1234", "1234");
    ModifyGroupResponse res = GroupchatService::ModifyGroup(req);
    EXPECT_EQ(RESULT_CODE::RESULT_SUCCESS, res.Result);
    EXPECT_EQ("Success", res.Status);
}

TEST(ModifyPrivateGroup, EmptyGroupName) {
    ModifyGroupRequest req(11, "khuong", "", "1234", "1234");
    ModifyGroupResponse res = GroupchatService::ModifyGroup(req);
    EXPECT_EQ(RESULT_CODE::RESULT_SUCCESS, res.Result);
    EXPECT_EQ("Success", res.Status);
}

TEST(ModifyPrivateGroup, InvalidPassword)
{
    ModifyGroupRequest req(11, "khuong", "Axis party", "1236", "1235");
    ModifyGroupResponse res = GroupchatService::ModifyGroup(req);
    EXPECT_EQ(RESULT_CODE::GROUP_OWNER_OR_PASSWORD_INVALID, res.Result);
    EXPECT_EQ("Group Owner or Password is Invalid", res.Status);
}

TEST(ModifyPrivateGroup, InvalidOwner)
{
    ModifyGroupRequest req(11, "dat", "Axis party", "1234", "1234");
    ModifyGroupResponse res = GroupchatService::ModifyGroup(req);
    EXPECT_EQ(RESULT_CODE::GROUP_OWNER_OR_PASSWORD_INVALID, res.Result);
    EXPECT_EQ("Group Owner or Password is Invalid", res.Status);
}

TEST(ModifyPublicGroup, EmptyGroupName)
{
    ModifyGroupRequest req(1, "khuong", "", "1234", "");
    ModifyGroupResponse res = GroupchatService::ModifyGroup(req);
    EXPECT_EQ(RESULT_CODE::GROUP_NAME_EMPTY, res.Result);
    EXPECT_EQ("Group name empty", res.Status);
}

TEST(ModifyPublicGroup, InvalidPassword)
{
    ModifyGroupRequest req(1, "khuong", "hoi diet quy", "1235", "1234");
    ModifyGroupResponse res = GroupchatService::ModifyGroup(req);
    EXPECT_EQ(RESULT_CODE::GROUP_OWNER_OR_PASSWORD_INVALID, res.Result);
    EXPECT_EQ("Group Owner or Password is Invalid", res.Status);
}

TEST(ModifyPublicGroup, InvalidOwner)
{
    ModifyGroupRequest req(1, "bao", "hoi diet quy", "1234", "1234");
    ModifyGroupResponse res = GroupchatService::ModifyGroup(req);
    EXPECT_EQ(RESULT_CODE::GROUP_OWNER_OR_PASSWORD_INVALID, res.Result);
    EXPECT_EQ("Group Owner or Password is Invalid", res.Status);
}

TEST(ModifyPublicGroup, ValidCase) {
    ModifyGroupRequest req(1, "khuong", "hoi diet quy", "1234", "");
    ModifyGroupResponse res = GroupchatService::ModifyGroup(req);
    EXPECT_EQ(RESULT_CODE::RESULT_SUCCESS, res.Result);
    EXPECT_EQ("Success", res.Status);
}

TEST(ReadGroup, InvalidGroup) {
    ReadGroupUserRequest req(0);
    ReadGroupUserResponse res = GroupchatService::ReadGroup(req);
    EXPECT_EQ(RESULT_CODE::GROUP_UNFOUND, res.Result);
    EXPECT_EQ("Group Unfound", res.Status);
}

TEST(ReadGroup, ValidCase) {
    ReadGroupUserRequest req(1);
    ReadGroupUserResponse res = GroupchatService::ReadGroup(req);
    EXPECT_EQ(RESULT_CODE::RESULT_SUCCESS, res.Result);
    EXPECT_EQ("Success", res.Status);
    vector<string> users;
    users.push_back("hai");
    users.push_back("hoang");
    EXPECT_EQ(users, res.users);
}

int main(int argc, char **argv)
{
    TestingServer::initializerServer();

    testing::InitGoogleTest(&argc, argv);
    int result = RUN_ALL_TESTS();

    TestingServer::shutdown();
    return 0;
}