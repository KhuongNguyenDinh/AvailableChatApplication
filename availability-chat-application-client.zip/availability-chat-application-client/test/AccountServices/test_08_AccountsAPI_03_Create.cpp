#include <gtest/gtest.h>

#include "AccountsAPI.h"
#include "clientClass.h"
#include "helper.h"

using namespace std;
using namespace Server::RestServer;
using namespace MyLibrary;
using namespace Client::RestAPI;
using namespace MyLibrary::Models::Requests;
using namespace MyLibrary::Models::Responses;

TEST(AccountsAPI_Create, Unauthenticated)
{
    CreateAccountRequest req("");
    RESULT_CODE res = AccountsAPI::postCreateAccount(req);
    EXPECT_EQ(RESULT_CODE::UNAUTHENTICATION, res);
}

TEST(AccountsAPI_Create, Unauthorizated)
{
    AuthenAccountRequest req1("andy", generateSHA1("123456789"));
    AuthenAccountResponse res1 = AccountsAPI::postAuthenAccount(req1);
    
    CreateAccountRequest req2(res1.AuthKey);
    RESULT_CODE res2 = AccountsAPI::postCreateAccount(req2);
    EXPECT_EQ(RESULT_CODE::UNAUTHENTICATION, res2);
}

TEST(AccountsAPI_Create, DuplicateUsername)
{
    AuthenAccountRequest req1("test", generateSHA1("000000000"));
    AuthenAccountResponse res1 = AccountsAPI::postAuthenAccount(req1);
    
    CreateAccountRequest req2(res1.AuthKey);
    req2.Username = "test";
    req2.Role = "0";
    req2.Password = "000000000";
    RESULT_CODE res2 = AccountsAPI::postCreateAccount(req2);
    EXPECT_EQ(RESULT_CODE::RESULT_UNKNOWN, res2);
}

TEST(AccountsAPI_Create, InvalidPassword)
{
    AuthenAccountRequest req1("test", generateSHA1("000000000"));
    AuthenAccountResponse res1 = AccountsAPI::postAuthenAccount(req1);
    
    CreateAccountRequest req2(res1.AuthKey);
    req2.Username = "test1";
    req2.Role = "1";
    req2.Password = "000000000000";
    RESULT_CODE res2 = AccountsAPI::postCreateAccount(req2);
    EXPECT_EQ(RESULT_CODE::RESULT_UNKNOWN, res2);
}

TEST(AccountsAPI_Create, ValidParameters)
{
    AuthenAccountRequest req1("test", generateSHA1("000000000"));
    AuthenAccountResponse res1 = AccountsAPI::postAuthenAccount(req1);
    
    CreateAccountRequest req2(res1.AuthKey);
    req2.Username = "test1";
    req2.Role = "1";
    req2.Password = "123456789";
    RESULT_CODE res2 = AccountsAPI::postCreateAccount(req2);
    EXPECT_EQ(RESULT_CODE::RESULT_SUCCESS, res2);
}

int main(int argc, char **argv)
{
    TestingServer::initializerServer();

    testing::InitGoogleTest(&argc, argv);
    int result = RUN_ALL_TESTS();

    TestingServer::shutdown();
    return 0;
}