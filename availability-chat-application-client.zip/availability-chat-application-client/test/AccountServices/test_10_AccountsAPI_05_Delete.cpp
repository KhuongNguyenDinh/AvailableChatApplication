#include <gtest/gtest.h>

#include "AccountsAPI.h"
#include "clientClass.h"
#include "helper.h"

using namespace std;
using namespace Server::RestServer;
using namespace MyLibrary;
using namespace Client::RestAPI;
using namespace MyLibrary::Models::Requests;
using namespace MyLibrary::Models::Responses;

TEST(AccountsAPI_Delete, Unauthenticated)
{
    DeleteAccountRequest req("");
    RESULT_CODE res = AccountsAPI::postDeleteAccount(req);
    EXPECT_EQ(RESULT_CODE::UNAUTHENTICATION, res);
}

TEST(AccountsAPI_Delete, UsernameNotFound)
{
    AuthenAccountRequest req1("test", generateSHA1("000000000"));
    AuthenAccountResponse res1 = AccountsAPI::postAuthenAccount(req1);

    DeleteAccountRequest req2(res1.AuthKey);
    req2.Username = "_____";
    RESULT_CODE res2 = AccountsAPI::postDeleteAccount(req2);
    EXPECT_EQ(RESULT_CODE::USERNAME_NOT_FOUND, res2);
}

TEST(AccountsAPI_Delete, ValidUsername)
{
    AuthenAccountRequest req1("test", generateSHA1("000000000"));
    AuthenAccountResponse res1 = AccountsAPI::postAuthenAccount(req1);
    AuthenAccountRequest req2("test1", generateSHA1("000000000"));
    AuthenAccountResponse res2 = AccountsAPI::postAuthenAccount(req2);

    DeleteAccountRequest req3(res1.AuthKey);
    req2.Username = "test1";
    RESULT_CODE res3 = AccountsAPI::postDeleteAccount(req3);
    EXPECT_EQ(RESULT_CODE::RESULT_SUCCESS, res3);

    DeleteAccountRequest req4(res2.AuthKey);
    req2.Username = "test";
    RESULT_CODE res4 = AccountsAPI::postDeleteAccount(req4);
    EXPECT_EQ(RESULT_CODE::UNAUTHENTICATION, res4);
}

int main(int argc, char **argv)
{
    TestingServer::initializerServer();

    testing::InitGoogleTest(&argc, argv);
    int result = RUN_ALL_TESTS();

    TestingServer::shutdown();
    return 0;
}