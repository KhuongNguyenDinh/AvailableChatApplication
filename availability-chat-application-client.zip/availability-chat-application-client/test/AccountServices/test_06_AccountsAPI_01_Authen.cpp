#include <gtest/gtest.h>

#include "AccountsAPI.h"
#include "clientClass.h"
#include "helper.h"

using namespace std;
using namespace Server::RestServer;
using namespace MyLibrary;
using namespace Client::RestAPI;
using namespace MyLibrary::Models::Requests;
using namespace MyLibrary::Models::Responses;

TEST(AccountsAPI_Authen, UsernameNotFound)
{
    AuthenAccountRequest req("_____", "_____");
    AuthenAccountResponse res = AccountsAPI::postAuthenAccount(req);
    EXPECT_EQ(RESULT_CODE::USERNAME_NOT_FOUND, res.Result);
    EXPECT_EQ("", res.AuthKey);
    EXPECT_EQ("", res.Role); 
}

TEST(AccountsAPI_Authen, InvalidPassword)
{
    AuthenAccountRequest req("test", "_____");
    AuthenAccountResponse res = AccountsAPI::postAuthenAccount(req);
    EXPECT_EQ(RESULT_CODE::PASSWORD_INVALID, res.Result);
    EXPECT_EQ("", res.AuthKey);
    EXPECT_EQ("", res.Role);
}

TEST(AccountsAPI_Authen, ValidAuthen)
{
    AuthenAccountRequest req("test", generateSHA1("000000000"));
    AuthenAccountResponse res = AccountsAPI::postAuthenAccount(req);
    EXPECT_EQ(RESULT_CODE::RESULT_SUCCESS, res.Result);
    EXPECT_EQ("0", res.Role);
}

TEST(AccountsAPI_Authen, Authenticated)
{
    clientClass *ClientClass = clientClass::getInstance();
    ClientClass->initialize();
    ClientClass->Username = "test";
    ClientClass->connectToServer();
    
    AuthenAccountRequest req("test", generateSHA1("000000000"));
    AuthenAccountResponse res = AccountsAPI::postAuthenAccount(req);
    EXPECT_EQ(RESULT_CODE::ACCOUNT_AUTHENTICATED, res.Result);
    EXPECT_EQ("", res.AuthKey);
    EXPECT_EQ("", res.Role);
}

int main(int argc, char **argv)
{
    TestingServer::initializerServer();

    testing::InitGoogleTest(&argc, argv);
    int result = RUN_ALL_TESTS();

    TestingServer::shutdown();
    return 0;
}