#include <gtest/gtest.h>

#include "helper.h"
#include "AccountsService.h"
#include "clientClass.h"

using namespace Server::RestServer::Services;

TEST(AccountsService_Update, Unauthenticated)
{
    UpdateAccountRequest req("");
    RESULT_CODE res = AccountsService::postUpdateAccount(req);
    EXPECT_EQ(RESULT_CODE::UNAUTHENTICATION, res);
}

TEST(AccountsService_Update, Unauthorizated_ChangePassword)
{
    AuthenAccountRequest req1("test1", generateSHA1("123456789"));
    AuthenAccountResponse res1 = AccountsService::postAuthenAccount(req1);

    UpdateAccountRequest req2(res1.AuthKey);
    req2.Username = "test";
    req2.Password = "123456789";
    req2.Role = "";
    RESULT_CODE res2 = AccountsService::postUpdateAccount(req2);
    EXPECT_EQ(RESULT_CODE::UNAUTHENTICATION, res2);
}

TEST(AccountsService_Update, Unauthorizated_ChangeRole)
{
    AuthenAccountRequest req1("test1", generateSHA1("123456789"));
    AuthenAccountResponse res1 = AccountsService::postAuthenAccount(req1);

    UpdateAccountRequest req2(res1.AuthKey);
    req2.Username = "test";
    req2.Password = "";
    req2.Role = "1";
    RESULT_CODE res2 = AccountsService::postUpdateAccount(req2);
    EXPECT_EQ(RESULT_CODE::UNAUTHENTICATION, res2);
}

TEST(AccountsService_Update, InvalidPassword)
{
    AuthenAccountRequest req1("test", generateSHA1("000000000"));
    AuthenAccountResponse res1 = AccountsService::postAuthenAccount(req1);

    UpdateAccountRequest req2(res1.AuthKey);
    req2.Username = "test";
    req2.Role = "";
    req2.Password = "000000000000";
    RESULT_CODE res2 = AccountsService::postUpdateAccount(req2);
    EXPECT_EQ(RESULT_CODE::RESULT_UNKNOWN, res2);
}

TEST(AccountsService_Update, ValidPassword)
{
    AuthenAccountRequest req1("test1", generateSHA1("123456789"));
    AuthenAccountResponse res1 = AccountsService::postAuthenAccount(req1);

    UpdateAccountRequest req2(res1.AuthKey);
    req2.Username = "test1";
    req2.Role = "";
    req2.Password = "000000000";
    RESULT_CODE res2 = AccountsService::postUpdateAccount(req2);
    EXPECT_EQ(RESULT_CODE::RESULT_SUCCESS, res2);
}

TEST(AccountsService_Update, ValidRole)
{
    AuthenAccountRequest req1("test", generateSHA1("000000000"));
    AuthenAccountResponse res1 = AccountsService::postAuthenAccount(req1);

    UpdateAccountRequest req2(res1.AuthKey);
    req2.Username = "test1";
    req2.Role = "0";
    RESULT_CODE res2 = AccountsService::postUpdateAccount(req2);
    EXPECT_EQ(RESULT_CODE::RESULT_SUCCESS, res2);
}

int main(int argc, char **argv)
{
    TestingServer::initializerServer();

    testing::InitGoogleTest(&argc, argv);
    int result = RUN_ALL_TESTS();

    TestingServer::shutdown();
    return 0;
}