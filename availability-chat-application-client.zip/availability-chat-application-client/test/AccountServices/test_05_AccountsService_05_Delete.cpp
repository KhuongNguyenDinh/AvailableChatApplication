#include <gtest/gtest.h>

#include "helper.h"
#include "AccountsService.h"
#include "clientClass.h"

using namespace Server::RestServer::Services;

TEST(AccountsService_Delete, Unauthenticated)
{
    DeleteAccountRequest req("");
    RESULT_CODE res = AccountsService::postDeleteAccount(req);
    EXPECT_EQ(RESULT_CODE::UNAUTHENTICATION, res);
}

TEST(AccountsService_Delete, UsernameNotFound)
{
    AuthenAccountRequest req1("test", generateSHA1("000000000"));
    AuthenAccountResponse res1 = AccountsService::postAuthenAccount(req1);

    DeleteAccountRequest req2(res1.AuthKey);
    req2.Username = "_____";
    RESULT_CODE res2 = AccountsService::postDeleteAccount(req2);
    EXPECT_EQ(RESULT_CODE::USERNAME_NOT_FOUND, res2);
}

TEST(AccountsService_Delete, ValidUsername)
{
    AuthenAccountRequest req1("test", generateSHA1("000000000"));
    AuthenAccountResponse res1 = AccountsService::postAuthenAccount(req1);
    AuthenAccountRequest req2("test1", generateSHA1("000000000"));
    AuthenAccountResponse res2 = AccountsService::postAuthenAccount(req2);

    DeleteAccountRequest req3(res1.AuthKey);
    req2.Username = "test1";
    RESULT_CODE res3 = AccountsService::postDeleteAccount(req3);
    EXPECT_EQ(RESULT_CODE::RESULT_SUCCESS, res3);

    DeleteAccountRequest req4(res2.AuthKey);
    req2.Username = "test";
    RESULT_CODE res4 = AccountsService::postDeleteAccount(req4);
    EXPECT_EQ(RESULT_CODE::UNAUTHENTICATION, res4);
}

int main(int argc, char **argv)
{
    TestingServer::initializerServer();

    testing::InitGoogleTest(&argc, argv);
    int result = RUN_ALL_TESTS();

    TestingServer::shutdown();
    return 0;
}