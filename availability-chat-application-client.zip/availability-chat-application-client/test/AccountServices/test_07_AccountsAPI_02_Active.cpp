#include <gtest/gtest.h>

#include "AccountsAPI.h"
#include "clientClass.h"
#include "helper.h"

using namespace std;
using namespace Server::RestServer;
using namespace MyLibrary;
using namespace Client::RestAPI;
using namespace MyLibrary::Models::Requests;
using namespace MyLibrary::Models::Responses;

int isWaiting = 0;

TEST(AccountsAPI_Active, Unauthenticated)
{
    ActiveAccountsRequest req("");
    ActiveAccountsResponse res = AccountsAPI::getActiveAccounts(req);
    EXPECT_EQ(RESULT_CODE::UNAUTHENTICATION, res.Result);
    EXPECT_EQ(0, res.Usernames.size());
}

TEST(AccountsAPI_Active, Authenticated_Empty)
{
    while(isWaiting);
    isWaiting = 1;
    AuthenAccountRequest req1("test", generateSHA1("000000000"));
    AuthenAccountResponse res1 = AccountsAPI::postAuthenAccount(req1);

    ActiveAccountsRequest req2(res1.AuthKey);
    ActiveAccountsResponse res2 = AccountsAPI::getActiveAccounts(req2);
    EXPECT_EQ(RESULT_CODE::RESULT_SUCCESS, res2.Result);
    EXPECT_EQ(0, res2.Usernames.size());
    isWaiting = 0;
}

TEST(AccountsAPI_Active, Authenticated)
{
    while(isWaiting);
    isWaiting = 1;
    clientClass *ClientClass = clientClass::getInstance();
    ClientClass->initialize();
    ClientClass->Username = "test0";
    ClientClass->connectToServer();
    ClientClass->initialize();
    ClientClass->Username = "test1";
    ClientClass->connectToServer();

    AuthenAccountRequest req1("test", generateSHA1("000000000"));
    AuthenAccountResponse res1 = AccountsAPI::postAuthenAccount(req1);

    ActiveAccountsRequest req2(res1.AuthKey);
    ActiveAccountsResponse res2 = AccountsAPI::getActiveAccounts(req2);
    EXPECT_EQ(RESULT_CODE::RESULT_SUCCESS, res2.Result);
    EXPECT_EQ(2, res2.Usernames.size());
    if (2 == res2.Usernames.size())
    {
        EXPECT_EQ(res2.Usernames[0], "test0");
        EXPECT_EQ(res2.Usernames[1], "test1");
    }
    isWaiting = 0;
}

int main(int argc, char **argv)
{
    TestingServer::initializerServer();

    testing::InitGoogleTest(&argc, argv);
    int result = RUN_ALL_TESTS();

    TestingServer::shutdown();
    return 0;
}