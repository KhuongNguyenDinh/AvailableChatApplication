-- MySQL dump 10.13  Distrib 5.7.31, for Linux (x86_64)
--
-- Host: 192.168.122.202    Database: USER
-- ------------------------------------------------------
-- Server version	5.7.31-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Account`
--

DROP TABLE IF EXISTS `Account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Account` (
  `USER_ID` int(11) NOT NULL AUTO_INCREMENT,
  `USERNAME` varchar(16) NOT NULL,
  `Password` varchar(9) NOT NULL,
  `ROLES` varchar(1) NOT NULL,
  PRIMARY KEY (`USER_ID`),
  UNIQUE KEY `USERNAME` (`USERNAME`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Account`
--

LOCK TABLES `Account` WRITE;
/*!40000 ALTER TABLE `Account` DISABLE KEYS */;
INSERT INTO `Account` VALUES (1,'admin','000000000','0'),(2,'bao','123456789','1'),(3,'nguyen','123456789','1'),(4,'khuong','123456789','1'),(5,'dat','123456789','1'),(6,'sang','123456789','1'),(7,'andy','123456789','1'),(8,'peter','123456789','1'),(9,'syan','123456789','1'),(11,'hai','123456789','1'),(12,'hoang','123456789','1'),(13,'meep','123456789','1'),(14,'bao1','123456789','1'),(15,'nguyen1','123456789','1'),(16,'khuong1','123456789','1'),(17,'dat1','123456789','1'),(18,'sang1','123456789','1'),(19,'hoang1','123456789','1'),(20,'hai1','123456789','1'),(21,'meep1','123456789','1'),(23,'decov25','000000000','0'),(50,'wibu_chua','123456789','2'),(51,'hai_chua','123546','1'),(55,'test','000000000','1'),(56,'admin_test','000000000','0'),(58,'test1','123456789','0');
/*!40000 ALTER TABLE `Account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Authentication`
--

DROP TABLE IF EXISTS `Authentication`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Authentication` (
  `Username` varchar(16) DEFAULT NULL,
  `Session` varchar(1) DEFAULT NULL,
  `Time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Authentication`
--

LOCK TABLES `Authentication` WRITE;
/*!40000 ALTER TABLE `Authentication` DISABLE KEYS */;
INSERT INTO `Authentication` VALUES ('khuong','0','2020-08-17 14:27:48'),('bao','0','2020-08-17 14:48:12'),('nguyen','1','2020-08-17 14:51:07');
/*!40000 ALTER TABLE `Authentication` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_room`
--

DROP TABLE IF EXISTS `chat_room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chat_room` (
  `ROOM_ID` int(11) NOT NULL AUTO_INCREMENT,
  `message_history` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ROOM_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=154 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room`
--

LOCK TABLES `chat_room` WRITE;
/*!40000 ALTER TABLE `chat_room` DISABLE KEYS */;
INSERT INTO `chat_room` VALUES (75,'./chat_history/75.txt'),(76,'./chat_history/76.txt'),(77,'./chat_history/77.txt'),(78,'./chat_history/78.txt'),(79,'./chat_history/79.txt'),(80,'./chat_history/80.txt'),(82,'./chat_history/82.txt'),(84,'./chat_history/84.txt'),(85,'./chat_history/85.txt'),(86,'./chat_history/86.txt'),(87,'./chat_history/87.txt'),(88,'./chat_history/88.txt'),(89,'./chat_history/89.txt'),(90,'./chat_history/90.txt'),(92,'./chat_history/92.txt'),(93,'./chat_history/93.txt'),(94,'./chat_history/94.txt'),(95,'./chat_history/95.txt'),(96,'./chat_history/96.txt'),(97,'./chat_history/97.txt'),(98,'./chat_history/98.txt'),(99,'./chat_history/99.txt'),(100,'./chat_history/100.txt'),(101,'./chat_history/101.txt'),(103,'./chat_history/103.txt'),(104,'./chat_history/104.txt'),(105,'./chat_history/105.txt'),(106,'./chat_history/106.txt'),(107,'./chat_history/107.txt'),(108,'./chat_history/108.txt'),(109,'./chat_history/109.txt'),(110,'./chat_history/110.txt'),(111,'./chat_history/111.txt'),(112,'./chat_history/112.txt'),(113,'./chat_history/113.txt'),(114,'./chat_history/114.txt'),(115,'./chat_history/115.txt'),(116,'./chat_history/116.txt'),(117,'./chat_history/117.txt'),(118,'./chat_history/118.txt'),(119,'./chat_history/119.txt'),(120,'./chat_history/120.txt'),(121,'./chat_history/121.txt'),(122,'./chat_history/122.txt'),(123,'./chat_history/123.txt'),(124,'./chat_history/124.txt'),(125,'./chat_history/125.txt'),(126,'./chat_history/126.txt'),(127,'./chat_history/127.txt'),(128,'./chat_history/128.txt'),(129,'./chat_history/129.txt'),(130,'./chat_history/130.txt'),(131,'./chat_history/131.txt'),(132,'./chat_history/132.txt'),(133,'./chat_history/133.txt'),(134,'./chat_history/134.txt'),(135,'./chat_history/135.txt'),(136,'./chat_history/136.txt'),(137,'./chat_history/137.txt'),(138,'./chat_history/138.txt'),(139,'./chat_history/139.txt'),(140,'./chat_history/140.txt'),(141,'./chat_history/141.txt'),(142,'./chat_history/142.txt'),(143,'./chat_history/143.txt'),(144,'./chat_history/144.txt'),(145,'./chat_history/145.txt'),(146,'./chat_history/146.txt'),(147,'./chat_history/147.txt'),(148,'./chat_history/148.txt'),(149,'./chat_history/149.txt'),(150,'./chat_history/150.txt'),(151,'./chat_history/151.txt'),(152,'./chat_history/152.txt'),(153,'./chat_history/153.txt');
/*!40000 ALTER TABLE `chat_room` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `chat_room_account`
--

DROP TABLE IF EXISTS `chat_room_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `chat_room_account` (
  `ROOM_ID` int(11) NOT NULL,
  `ACC_USERNAME` varchar(16) NOT NULL,
  PRIMARY KEY (`ROOM_ID`,`ACC_USERNAME`),
  KEY `ACC_USERNAME` (`ACC_USERNAME`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `chat_room_account`
--

LOCK TABLES `chat_room_account` WRITE;
/*!40000 ALTER TABLE `chat_room_account` DISABLE KEYS */;
INSERT INTO `chat_room_account` VALUES (129,',meep'),(109,'admin'),(122,'admin'),(133,'admin'),(119,'andy'),(120,'andy'),(134,'andy'),(139,'andy'),(90,'bao'),(95,'bao'),(112,'bao'),(122,'bao'),(127,'bao'),(134,'bao'),(135,'bao'),(136,'bao'),(96,'bao1'),(141,'bao1'),(152,'bao1'),(107,'dat'),(137,'dat'),(153,'decov25'),(105,'hai'),(106,'hai'),(126,'hai'),(128,'hai'),(149,'hai1'),(144,'hai_chua'),(90,'hoang'),(97,'hoang'),(104,'hoang'),(105,'hoang'),(107,'hoang'),(108,'hoang'),(111,'hoang'),(117,'hoang'),(130,'hoang'),(131,'hoang'),(132,'hoang'),(133,'hoang'),(138,'hoang'),(139,'hoang'),(140,'hoang'),(141,'hoang'),(142,'hoang'),(143,'hoang'),(144,'hoang'),(145,'hoang'),(146,'hoang'),(147,'hoang'),(148,'hoang'),(149,'hoang'),(150,'hoang'),(153,'hoang'),(98,'hoang1'),(108,'hoang1'),(126,'hoang1'),(151,'hoang1'),(152,'hoang1'),(93,'khuong'),(94,'khuong'),(99,'khuong'),(104,'khuong'),(106,'khuong'),(109,'khuong'),(112,'khuong'),(115,'KHUONG'),(116,'khuong'),(124,'khuong'),(91,'khuong1'),(92,'khuong1'),(94,'khuong1'),(100,'khuong1'),(110,'khuong1'),(114,'khuong1'),(148,'khuong1'),(117,'khuong8'),(118,'meep'),(123,'meep'),(124,'meep'),(125,'meep'),(127,'meep'),(138,'meep'),(110,'meep1'),(142,'meep1'),(91,'nguyen'),(93,'nguyen'),(97,'nguyen'),(98,'nguyen'),(101,'nguyen'),(103,'nguyen'),(125,'nguyen'),(136,'nguyen'),(137,'nguyen'),(92,'nguyen1'),(95,'nguyen1'),(96,'nguyen1'),(101,'nguyen1'),(145,'nguyen1'),(151,'nguyen1'),(121,'peter'),(132,'peter'),(99,'sang'),(103,'sang'),(111,'sang'),(113,'sang'),(114,'sang'),(118,'sang'),(120,'sang'),(128,'sang'),(129,'sang'),(100,'sang1'),(113,'sang1'),(116,'sang1'),(119,'sang1'),(150,'sang1'),(121,'syan'),(123,'syan'),(140,'syan'),(143,'wibu_chua');
/*!40000 ALTER TABLE `chat_room_account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_chat`
--

DROP TABLE IF EXISTS `group_chat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_chat` (
  `GROUP_ID` int(11) NOT NULL AUTO_INCREMENT,
  `GROUP_NAME` varchar(32) NOT NULL,
  `ACCESSIBLE_MODIFIER` varchar(1) NOT NULL,
  `OWNER` varchar(16) NOT NULL,
  `PASSWORD` varchar(4) DEFAULT NULL,
  `message_history` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`GROUP_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_chat`
--

LOCK TABLES `group_chat` WRITE;
/*!40000 ALTER TABLE `group_chat` DISABLE KEYS */;
INSERT INTO `group_chat` VALUES (1,'hoi diet quy','0','khuong',NULL,'./group_chat_history/1.txt'),(2,'hoi ban tron','0','khuong',NULL,'./group_chat_history/2.txt'),(3,'Sword master of Shimosa','0','bao',NULL,'./group_chat_history/3.txt'),(4,'Pirate land Orleans','0','bao',NULL,'./group_chat_history/4.txt'),(5,'Gate of Chaldea','0','nguyen',NULL,'./group_chat_history/5.txt'),(6,'Decov25','0','Dat',NULL,'./group_chat_history/6.txt'),(7,'Falling Temple SOLOMON','1','Dat','1234','./group_chat_history/7.txt'),(8,'Khuong Wibu trua','1','Dat','1234','./group_chat_history/8.txt'),(9,'giao doan Eris','1','khuong','1234','./group_chat_history/9.txt'),(10,'Mystery of Shinjuku','1','hoang','1234','./group_chat_history/10.txt'),(11,'Axis party','1','khuong','1234','./group_chat_history/11.txt'),(12,'MeepEmpire','1','bao','1234','./group_chat_history/12.txt'),(16,'huhu','1','hoang','666','./group_chat_history/16.txt'),(19,'grPrivatete','1','sang','1239','./group_chat_history/19.txt'),(20,'gr Public','0','sang',NULL,'./group_chat_history/20.txt');
/*!40000 ALTER TABLE `group_chat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `group_chat_account`
--

DROP TABLE IF EXISTS `group_chat_account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_chat_account` (
  `GROUP_ID` int(11) NOT NULL,
  `ACC_USERNAME` varchar(16) NOT NULL,
  PRIMARY KEY (`GROUP_ID`,`ACC_USERNAME`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `group_chat_account`
--

LOCK TABLES `group_chat_account` WRITE;
/*!40000 ALTER TABLE `group_chat_account` DISABLE KEYS */;
INSERT INTO `group_chat_account` VALUES (1,'hai'),(1,'hoang'),(2,'bao'),(2,'hoang'),(3,'hoang'),(4,'hoang'),(5,'hoang'),(6,'Dat'),(6,'hoang'),(7,'bao'),(7,'dat'),(7,'hoang'),(7,'khuong'),(7,'nguyen'),(7,'sang'),(8,'hoang'),(8,'Sayonara'),(9,'hai'),(10,'hai'),(10,'hoang'),(10,'khuong'),(10,'nguyen'),(10,'SevenEleven'),(11,'bao'),(11,'hoang'),(11,'SevenEleven'),(12,'bao'),(16,'decov25'),(16,'meep'),(16,'meep1'),(19,'dat1'),(19,'hai_chua'),(19,'meep1'),(19,'sang'),(19,'test1'),(20,'hai1'),(20,'hai_chua'),(20,'khuong1'),(20,'meep1'),(20,'sang'),(20,'sang1'),(20,'test'),(20,'test1');
/*!40000 ALTER TABLE `group_chat_account` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-09-01  9:12:00
