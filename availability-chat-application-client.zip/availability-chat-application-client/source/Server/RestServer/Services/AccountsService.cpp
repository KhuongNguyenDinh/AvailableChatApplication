#include "AccountsService.h"
#include "Database.h"
#include "ChatServer.h"

Database *MySql = Database::getInstance();

namespace Server::RestServer::Services
{
    vector<pair<Account *, string>> AccountsService::AuthKeys;

    int AccountsService::addAccountAndKey(Account *account, string *key)
    {
        *key = generateAuthenKey();
        for (int i = 0; i < AuthKeys.size(); i++)
        {
            if (AuthKeys[i].second == *key)
                *key = generateAuthenKey();
            if (AuthKeys[i].first->Username == account->Username)
            {
                AuthKeys[i].second = *key;
                return 1;
            }
        }
        pair<Account *, string> _pair;
        _pair.first = account;
        _pair.second = *key;
        AuthKeys.push_back(_pair);
        return 0;
    }

    Account *AccountsService::getAccountByKey(string key)
    {
        for (auto item : AuthKeys)
            if (item.second == key)
                return item.first;
        return NULL;
    }

    ActiveAccountsResponse AccountsService::getActiveAccounts(
        ActiveAccountsRequest req)
    {
        ActiveAccountsResponse res;
        vector<string> usernames;
        vector<ClientSock *> clientSocks = ChatServer::getInstance()->Clients;
        for (auto item : clientSocks)
            usernames.push_back(item->Username);
        Account *account = getAccountByKey(req.AuthKey);
        if (!account)
        {
            res.Result = RESULT_CODE::UNAUTHENTICATION;
            return res;
        }

        res.Usernames = usernames;
        res.Result = RESULT_CODE::RESULT_SUCCESS;
        res.Usernames = usernames;
        return res;
    }

    AuthenAccountResponse AccountsService::postAuthenAccount(AuthenAccountRequest req)
    {
        AuthenAccountResponse res;

        Account *account = MySql->readAccount(req.Username);
        vector<ClientSock *> clientSocks = ChatServer::getInstance()->Clients;
        for (auto item : clientSocks)
            if (item->Username == req.Username)
            {
                res.Result = RESULT_CODE::ACCOUNT_AUTHENTICATED;
                return res;
            }
        if (!account)
        {
            res.Result = RESULT_CODE::USERNAME_NOT_FOUND;
            return res;
        }
        if (generateSHA1(account->Password) != req.Password)
        {
            res.Result = RESULT_CODE::PASSWORD_INVALID;
            delete account;
            return res;
        }
        string *key = new string("");
        addAccountAndKey(account, key);
        res.AuthKey = *key;
        res.Result = RESULT_CODE::RESULT_SUCCESS;
        res.Role = account->Role;
        return res;
    }

    AccountsResponse AccountsService::getAllAccounts(AccountsRequest req)
    {
        AccountsResponse res;
        Account *account = getAccountByKey(req.AuthKey);
        if (!account)
        {
            res.Result = RESULT_CODE::UNAUTHENTICATION;
            return res;
        }

        vector<Account> accounts = MySql->readAllAccounts();
        for (auto item : accounts)
            res.Accounts.push_back(item);
        res.Result = RESULT_CODE::RESULT_SUCCESS;
        return res;
    }

    RESULT_CODE AccountsService::postCreateAccount(CreateAccountRequest req)
    {
        RESULT_CODE res = RESULT_CODE::RESULT_UNKNOWN;
        Account *account = getAccountByKey(req.AuthKey);
        if (!account || account->Role != "0")
        {
            res = RESULT_CODE::UNAUTHENTICATION;
            return res;
        }

        account = new Account(
            req.Username,
            req.Password,
            req.Role);
        if (MySql->createAccount(account))
            return RESULT_SUCCESS;

        return res;
    }

    RESULT_CODE AccountsService::postUpdateAccount(UpdateAccountRequest req)
    {
        RESULT_CODE res = RESULT_CODE::RESULT_UNKNOWN;
        Account *account = getAccountByKey(req.AuthKey);
        if (!account)
        {
            res = RESULT_CODE::UNAUTHENTICATION;
            return res;
        }
        Account *accountChanging = MySql->readAccount(req.Username);

        if (!accountChanging)
        {
            res = RESULT_CODE::USERNAME_NOT_FOUND;
            return res;
        }

        if (accountChanging->Role != req.Role && req.Role != "")
        {
            if (account->Role != "0")
            {
                res = RESULT_CODE::UNAUTHENTICATION;
                return res;
            }
            if (!MySql->updateRole(req.Username, req.Role))
                return res;
        }
        if (accountChanging->Password != req.Password && req.Password != "")
        {
            if (account->Username != accountChanging->Username)
            {
                res = RESULT_CODE::UNAUTHENTICATION;
                return res;
            }
            if (!MySql->updatePassword(req.Username, req.Password))
                return res;
        }

        return RESULT_CODE::RESULT_SUCCESS;
    }

    RESULT_CODE AccountsService::postDeleteAccount(DeleteAccountRequest req)
    {
        RESULT_CODE res = RESULT_CODE::RESULT_UNKNOWN;
        Account *account = getAccountByKey(req.AuthKey);
        if (!account || account->Role != "0")
        {
            res = RESULT_CODE::UNAUTHENTICATION;
            return res;
        }

        account = MySql->readAccount(req.Username);

        if (!account)
        {
            res = RESULT_CODE::USERNAME_NOT_FOUND;
            return res;
        }

        if (MySql->deleteAccount(req.Username))
        {
            for (int i = 0; i < AuthKeys.size(); i++)
                if (AuthKeys[i].first->Username == req.Username)
                {
                    AuthKeys.erase(AuthKeys.begin() + i);
                    break;
                }
            return RESULT_CODE::RESULT_SUCCESS;
        }

        return res;
    }

} // namespace Server::RestServer::Services
