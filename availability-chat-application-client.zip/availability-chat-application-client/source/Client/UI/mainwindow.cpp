#include "mainwindow.h"
#include <iostream>
#include <string>
#include <string.h>
#include <QWidget>
#include <QPixmap>
#include "./ui_mainwindow.h"
#include <QString>
#include "clientClass.h"
#include "AccountsAPI.h"
#include "MyLibrary.h"
#include "chatbox.h"

using namespace std;
using namespace MyLibrary;
using namespace Client::RestAPI;
using namespace MyLibrary::Models::Requests;
using namespace MyLibrary::Models::Responses;
using namespace Client::RestAPI;

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    char cwd[PATH_MAX];
    getcwd(cwd, sizeof(cwd));
    string fileName = cwd;
    fileName = clientClass::getInstance()->getExecutionPath() +"/resources/logo2";
    fileName = fileName + ".png";
    QPixmap pix(QString::fromStdString(fileName)); 
    ui->label_4->setPixmap(pix.scaled(300,300,Qt::KeepAspectRatio));
    //ui->label_4->setPixmap(pix);
    this->setWindowTitle("Login Screen");
}
MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_Login_clicked()
{ 
    clientClass::getInstance()->Username = ui->lineEdit_2->text().toStdString();
    QString password = ui->lineEdit->text();
    if (clientClass::getInstance()->initialize() != RESULT_SUCCESS)
    {
        ui->lineEdit->clear();
        ui->label_3->setText(QString::fromStdString("Network error!"));
        qDebug() << "Initializing socket failed.\nGo back now.";
        return;
    }
    if (clientClass::getInstance()->connectToServer() != RESULT_SUCCESS)
    {
        ui->lineEdit->clear();
        ui->label_3->setText(QString::fromStdString("Network error!"));
        qDebug() << "Go back now.";
        return;
    }
    AuthenAccountRequest req(clientClass::getInstance()->Username, password.toStdString());
    AuthenAccountResponse res = AccountsAPI::postAuthenAccount(req);
    clientClass::getInstance()->AuthKey = res.AuthKey;
    clientClass::getInstance()->Role = res.Role;
    int result = RESULT_CODE::RESULT_UNKNOWN;
    switch (res.Result)
        {
        case RESULT_CODE::GENERAL_RESULT_SUCCESSFUL:{
            qDebug() << "Login success";
            ui->label_3->clear();
            ui->lineEdit->clear();
            ui->lineEdit_2->clear();
            close();
            break;
        }
        case RESULT_CODE::AUTHEN_ACCOUNT_INVALID_USERNAME:
            ui->label_3->setText(QString::fromStdString("Username not found!"));
            qDebug() << "Username not found";
            clientClass::getInstance()->Role = "-1";
            clientClass::getInstance()->Logout();
            break;
        case RESULT_CODE::AUTHEN_ACCOUNT_INVALID_PASSWORD:
            ui->lineEdit->clear();
            ui->label_3->setText(QString::fromStdString("Incorrect password!"));
            qDebug() << "Incorrect password";
            clientClass::getInstance()->Role = "-1";
            clientClass::getInstance()->Logout();
            break;
        case RESULT_CODE::AUTHEN_ACCOUNT_AUTHENTICATED:
            ui->lineEdit->clear();
            ui->label_3->setText(QString::fromStdString("Account is login somewhere else!"));
            qDebug() << "Account already authenticate";
            clientClass::getInstance()->Role = "-1";
            clientClass::getInstance()->Logout();
            break;
        default:
            ui->lineEdit->clear();
            ui->label_3->setText(QString::fromStdString("Network Error!"));
            qDebug() << "API error";
            clientClass::getInstance()->Role = "-1";
            clientClass::getInstance()->Logout();
            break;
        }

}

void MainWindow::on_Exit_clicked()
{
    qDebug() << "Exit click";
    clientClass::getInstance()->Role = "-1";
    close();
}
