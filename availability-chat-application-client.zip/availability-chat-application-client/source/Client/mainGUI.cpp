#include "MyLibrary.h"
#include "AccountsAPI.h"
#include "clientClass.h"
#include "adminInterface.h"
#include "mainwindow.h"
#include <QApplication>

#include <iostream>

using namespace std;
using namespace MyLibrary;
using namespace Client::RestAPI;
using namespace MyLibrary::Models::Requests;
using namespace MyLibrary::Models::Responses;

tagClass tagmain;

//int comeToLogin(clientClass *&clientUser, menuClass &menu);

int main(int argc, char *argv[])
{
    int result = RESULT_CODE::RESULT_UNKNOWN;
    if ((result = AppSetting::loadSettingClientFromFile()))
        return result;
    clientClass *clientUser = clientClass::getInstance();
    
    QApplication a(argc, argv);
    MainWindow w;
    chatbox *b = chatbox::getInstance();
    while(1){      
        clientClass::getInstance()->Role = "-1";
        w.show();
        a.exec();
        //exit
        if(clientClass::getInstance()->Role == "-1"){
            //clientClass::getInstance()->Logout();
            break;
        } 
        b->show();
        b->init();
        a.exec();
        //logout
        if(clientClass::getInstance()->Role == "-1"){
            clientClass::getInstance()->Logout();
            continue;
        }
        clientClass::getInstance()->Logout();   
        break;
    }
    return 0;
}
