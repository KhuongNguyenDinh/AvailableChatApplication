#include "tagClass.h"


tagClass::tagClass(){
    Username = NULL;
}